﻿namespace SlackAPI.Models
{
    public class SlackMessage
    {
        public string SlackChannel { get; set; }
        public string Message { get; set; }
    }
}
