﻿using AuctionLeague.Data.Auction;

namespace AuctionLeague.Data.Slack
{
    public class SlackAuctionData : AuctionData
    {
        public string Channel { get; set; }
    }
}
