﻿namespace AuctionLeague.Data.FplPlayer;

public enum Position
{
    Unknown,
    GKP,
    DEF,
    MID,
    FWD
}