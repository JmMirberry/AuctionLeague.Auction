﻿using AuctionLeague.Data.FplPlayer;

namespace AuctionLeague.Data.Settings;

public class AutonominationSettings
{
    public Position Position { get; set; }
    public double MinValue { get; set; }
}