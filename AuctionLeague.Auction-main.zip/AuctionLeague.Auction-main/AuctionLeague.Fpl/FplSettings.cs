﻿namespace AuctionLeague.Fpl;

public class FplSettings
{
    public string FplApiUrl { get; set; }
}