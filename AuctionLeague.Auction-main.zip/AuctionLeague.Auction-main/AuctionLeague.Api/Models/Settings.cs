﻿namespace SlackAPI.Models
{
    public class Settings
    {
        public string SlackAccessToken { get; set; }
        public string SlackSigningSecret { get; set; }
    }
}
